<?php
    $path = preg_replace('/wp-content(?!.*wp-content).*/', '', __DIR__);
    include($path . 'wp-load.php');
    
    require_once(__DIR__ . '/vendor/autoload.php');
    
    use QuickBooksOnline\API\DataService\DataService;
    
    $config = include('config.php');
    
    session_start();
    
    $dataService = DataService::Configure(array(
        'auth_mode' => 'oauth2',
        'ClientID' => $config['client_id'],
        'ClientSecret' => $config['client_secret'],
        'RedirectURI' => $config['oauth_redirect_uri'],
        'scope' => $config['oauth_scope'],
        'baseUrl' => "development"
    ));
    
    $OAuth2LoginHelper = $dataService->getOAuth2LoginHelper();
    $authUrl = $OAuth2LoginHelper->getAuthorizationCodeURL();
    
    // Store the url in PHP Session Object;
    $_SESSION['authUrl'] = $authUrl;
    
    //set the access token using the auth object
    if (isset($_SESSION['sessionAccessToken'])) {
        
        $accessToken = $_SESSION['sessionAccessToken'];
        echo '<pre>';
        print_r($accessToken);
        echo '</pre>';
        //update_post_meta(1, 'accessTokenQB', $accessToken->getAccessToken());
        $accessTokenJson = array('token_type' => 'bearer',
            'access_token' => $accessToken->getAccessToken(),
            'refresh_token' => $accessToken->getRefreshToken(),
            'x_refresh_token_expires_in' => $accessToken->getRefreshTokenExpiresAt(),
            'expires_in' => $accessToken->getAccessTokenExpiresAt()
        );
        $dataService->updateOAuth2Token($accessToken);
        $oauthLoginHelper = $dataService->getOAuth2LoginHelper();
        $CompanyInfo = $dataService->getCompanyInfo();

        echo '</br>Access Token:<pre>';
        print_r($accessTokenJson);
        echo '</pre></br>';
    }
    else{
        echo '</br><h2>No sessionAccessToken</h2></br>';
    }

?>

<?php
    $servername = "localhost";
    $username = "matrixli_fetsw";
    $password = "ca{PpQw()A2K";
    $dbname = "matrixli_fetsw";
    
    // Create connection to wordpress db to insert a meta with accessToken
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // If session with access token exist then save in meta
    if (isset($_SESSION['sessionAccessToken'])) {
    
        $sessionAccessToken = $_SESSION['sessionAccessToken'];
        
        
        $sql = "UPDATE wp_postmeta SET meta_value='" . $accessToken->getAccessToken() . "' WHERE post_id=1 AND meta_key='accessTokenQB'";
       // $sql2 = "UPDATE wp_postmeta SET meta_value='" . $sessionAccessToken . "' WHERE post_id=1 AND meta_key='sessionAccessToken'";
    
        //    $sql = "UPDATE wp_postmeta SET  (post_id, meta_key, meta_value)
        //VALUES ('1', 'accessTokenQB', '". $accessToken->getAccessToken(). "' )";
        
        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully" . "<br>";
        } else {
            echo "Error updating record: " . $conn->error . "<br>";
        }
    
//        if ($conn->query($sql2) === TRUE) {
//            echo "Record updated successfully" . "<br>";
//        } else {
//            echo "Error updating record: " . $conn->error . "<br>";
//        }
    
    
        update_post_meta(1,'accessTokenQB',$accessToken->getAccessToken());
        update_post_meta(1,'sessionAccessToken', array( 'session'=>$sessionAccessToken) );
    }
    
    // Get from database accessToken saved from session to use in curl
    $sql3 = "SELECT meta_value FROM wp_postmeta WHERE meta_key='accessTokenQB' AND post_id=1";
    $result = $conn->query($sql3);
    print_r($result);
    $row = $result->fetch_assoc();
    $accessTokenQB = $row["meta_value"];
    print_r($accessTokenQB);
    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            print_r($result);
            echo "accessTokenQB: " . $row["meta_value"] . "<br>";
        }
    } else {
        echo "0 results";
    }
    
    $conn->close();
    
    $sessionAccessToken = get_post_meta(1,'sessionAccessToken',true);
    echo 'sessionAccessToken : <br>';
    print_r($sessionAccessToken);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="apple-touch-icon icon shortcut" type="image/png" href="https://plugin.intuitcdn.net/sbg-web-shell-ui/6.3.0/shell/harmony/images/QBOlogo.png">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="views/common.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script>

        var url = '<?php echo $authUrl; ?>';

        var OAuthCode = function (url) {

            this.loginPopup = function (parameter) {
                this.loginPopupUri(parameter);
            }

            this.loginPopupUri = function (parameter) {

                // Launch Popup
                var parameters = "location=1,width=800,height=650";
                parameters += ",left=" + (screen.width - 800) / 2 + ",top=" + (screen.height - 650) / 2;

                var win = window.open(url, 'connectPopup', parameters);
                var pollOAuth = window.setInterval(function () {
                    try {

                        if (win.document.URL.indexOf("code") != -1) {
                            window.clearInterval(pollOAuth);
                            win.close();
                            location.reload();
                        }
                    } catch (e) {
                        console.log(e)
                    }
                }, 100);
            }
        }


        var apiCall = function () {
            this.getCompanyInfo = function () {
                /*
                AJAX Request to retrieve getCompanyInfo
                 */
                $.ajax({
                    type: "GET",
                    url: "apiCall.php",
                }).done(function (msg) {
                    $('#apiCall').html(msg);
                });
            }

            this.refreshToken = function () {
                $.ajax({
                    type: "POST",
                    url: "refreshToken.php",
                }).done(function (msg) {

                });
            }
        }

        var oauth = new OAuthCode(url);
        var apiCall = new apiCall();
    </script>
</head>
<body>

<div class="container">
    
    <h1>
        <a href="http://developer.intuit.com">
            <img src="views/quickbooks_logo_horz.png" id="headerLogo">
        </a>
    
    </h1>
    
    <hr>
    
    <div class="well text-center">
        
        <h1>QuickBooks HelloWorld sample application</h1>
        <h2>Demonstrate Connect to QuickBooks flow and API Request</h2>
        
        <br>
    
    </div>
    
    <p>If there is no access token or the access token is invalid, click the
        <b>Connect to QuickBooks</b> button below.
    </p>
    <pre id="accessToken">
        <style="background-color:#efefef;overflow-x:scroll"><?php
            $displayString = isset($accessTokenJson) ? $accessTokenJson : "No Access Token Generated Yet";
            echo json_encode($displayString, JSON_PRETTY_PRINT); ?>
    </pre>
    <button class="btn btn-success" onclick="oauth.loginPopup()">Token Generate</button>
    <hr/>
    
    <h2>Make an API call</h2>
    <p>If there is no access token or the access token is invalid, click either the
        <b>Connect to QucikBooks</b> button above.
    </p>
    <pre id="apiCall"></pre>
    <button type="button" class="btn btn-success" onclick="apiCall.getCompanyInfo()">Get Company Info</button>
    
    <hr/>

</div>
<div class="info"></div>
<script>
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://sandbox-quickbooks.api.intuit.com/v3/company/123146365467839/companyinfo/123146365467839",
        "method": "GET",
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Accept": "application/json",
            "Authorization": "Bearer <?php echo $accessTokenQB; ?>"
        }
    };

    jQuery.ajax(settings).done(function (response) {
        console.log(response);
        jQuery('.info').html(response);
    });
</script>

<?php
    
    $curl = curl_init();
    
    curl_setopt_array($curl,
        array(
            CURLOPT_URL => "https://sandbox-quickbooks.api.intuit.com/v3/company/123146365467839/invoice",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
                                      "Line": [
                                        {
                                          "Amount": 132.00,
                                          "DetailType": "SalesItemLineDetail",
                                          "SalesItemLineDetail": {
                                            "ItemRef": {
                                              "value": "26",
                                              "name": "Garden Supplies1"
                                            },
                                            "Qty": 1
                                          }
                                        }
                                      ],
                                      "CustomerRef": {
                                        "value": "64"
                                      }
                                    }',
            CURLOPT_HTTPHEADER => array(
                "Accept: application/json",
                "Accept-Encoding: gzip, deflate",
                "Authorization: Bearer " . $accessTokenQB,
                "cache-control: no-cache",
                "Connection: keep-alive",
                "Content-Type: application/json",
            )
        )
    );
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo '<pre>';
        print_r($response);
        echo '</pre>';
    }

?>

</body>
</html>
