<?php
        return array(
            'authorizationRequestUrl' => 'https://appcenter.intuit.com/connect/oauth2',
            'tokenEndPointUrl' => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
            'client_id' => 'Q09Hb1XGwD9sQ6d3Bso8jCBDIMYCYZfgP9GGXfGzcOJb2es24C',
            'client_secret' => 'qSuc6Bp8u9rdkR6wNfcsVdzhqJsMulFNymLUQdWE',
            'oauth_scope' => 'com.intuit.quickbooks.accounting',
            'oauth_redirect_uri' => 'https://matrix.lifetimeshutters.com/wp-content/themes/storefront-child/quickBooks/callback.php',
        )
    
    
    // Client id and secret from lifetimeshutters
//    return array(
//        'authorizationRequestUrl' => 'https://appcenter.intuit.com/connect/oauth2',
//        'tokenEndPointUrl' => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
//        'client_id' => 'Q09Hb1XGwD9sQ6d3Bso8jCBDIMYCYZfgP9GGXfGzcOJb2es24C',
//        'client_secret' => 'qSuc6Bp8u9rdkR6wNfcsVdzhqJsMulFNymLUQdWE',
//        'oauth_scope' => 'com.intuit.quickbooks.accounting',
//        'oauth_redirect_uri' => 'https://dematrix.richmond-shutters.co.uk/HelloWorld-PHP/callback.php',
//    )
    
    // working setup
    // Client id and secret from marian93nes@gmail.com
    
    //    return array(
    //        'authorizationRequestUrl' => 'https://appcenter.intuit.com/connect/oauth2',
    //        'tokenEndPointUrl' => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
    //        'client_id' => 'Q0Yt4H7iQBshVyBD4BIUQsyO4goyJVDuy3pSezTbEAVrhCOMSc',
    //        'client_secret' => 'WruEdNkpRhktvgZpaF8qna2TqxQgmcOOR4O7tK6A',
    //        'oauth_scope' => 'com.intuit.quickbooks.accounting',
    //        'oauth_redirect_uri' => 'https://dematrix.richmond-shutters.co.uk/HelloWorld-PHP/callback.php',
    //    )
?>
